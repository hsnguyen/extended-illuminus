#########################################################################
############ Some basic code for outputting the results #################
############ from Illuminus 
############ Taane Clark: last updated 1/8/2007
#########################################################################

########################
### read in the data ###
########################

example <- as.matrix(read.table("example.txt", header=T)) ## raw data 
calls1 <- as.matrix(read.table("out_calls", header=F))  ## calls 

########################
### ploting function ###
########################

plotthe <- function(j)
{

ncol3<-  dim(example)[2]
nrow3 <- dim(calls1)[1]

par(ask = TRUE)

for(i in j)
{
print(table(calls1[i,-c(1,2,3,4)]))
xx <- as.numeric(unlist(example[i,seq(4,ncol3-1,by=2)]))
yy <- as.numeric(unlist(example[i,seq(5,ncol3,  by=2)]))
mx <- max(xx,na.rm=T)
my <- max(yy,na.rm=T)
cc <- (yy-xx)/(xx+yy)
ss <- log(as.numeric(xx)+as.numeric(yy))
missing <- (as.numeric(xx)<=0 | as.numeric(yy) <= 0) | (is.na(xx) | is.na(yy))
cc[ missing ] <- 0.0
ss[ missing ] <- 0.0

############ plot 1: raw scale ###################

plot(xx[!missing],yy[!missing],main=paste(as.character(example[i,1]),as.character(example[i,2]),
as.character(calls1[i,3]),as.character(calls1[i,4]),"miss = ",sum(1*missing)),xlab="A",ylab="B",
xlim=c(0,mx),ylim=c(0,my),type="n")
points(xx[!missing],yy[!missing],pch=20, col = as.numeric(calls1[i,-c(1,2,3,4)])[!missing],cex=0.5) 

######## plot 2: contrast / strength scale ########

plot(cc,ss,main=paste(as.character(example[i,1]),as.character(example[i,2]),
as.character(calls1[i,3]),as.character(calls1[i,4])),xlab="Contrast",ylab="Strength",type="n") 
points(cc,ss,pch=20, col = as.numeric(calls1[i,-c(1,2,3,4)]),cex=0.5)
}
}

par(mfrow=c(1,2))

## plot SNP 1 ###
plotthe(1)

## plot SNPs 10:20
plotthe(c(10:20))









