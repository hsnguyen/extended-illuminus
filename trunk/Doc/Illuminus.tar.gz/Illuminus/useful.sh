perl -ne '{$_ =~ s/\s+$/\n/g ; print $_ }' file > newfile # removes trailing whitespace

