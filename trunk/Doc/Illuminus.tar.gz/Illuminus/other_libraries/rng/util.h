
void print_3D_array_int(int*, int, int, int);
void print_mat_int(int*, int, int);
void print_mat_double(double*, int, int);
void sequential_mean(double*, double*, double);
void sequential_variance(double*, double*, double*, double);
void sequential_sd(double*, double*, double*, double);
void sequential_mean_vec(double*, double*, double, int);
void sequential_variance_vec(double*, double*, double*, double, int);
void sequential_sd_vec(double*, double*, double*, double, int);
